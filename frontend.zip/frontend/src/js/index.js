// Main js file

// Your app code
console.log(`Hello`);